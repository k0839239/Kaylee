def times_ten(num):
    return num * 10

if __name__ == "__main__":
    input_number = input("Enter value to multiply times 10")
    print(times_ten(int(input_number)))


